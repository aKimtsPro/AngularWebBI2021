export class Livre {
    titre: string;
    description: string;
}